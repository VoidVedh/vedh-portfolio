# Vedh Naik — Developer Profile

A personal developer profile site. Combines the "what I build" of GitHub, the
"who I am" of LinkedIn, and the "what I'm learning" of X/Twitter into one
original page — with a terminal easter egg as the signature feature.

## Stack

Plain **HTML / CSS / vanilla JavaScript**. No framework, no build step, no
backend, no database. Open `index.html` in a browser, or serve the folder
with any static server (e.g. `npx serve .`).

## Folder structure

```
portfolio/
├── index.html        Page structure/markup only — no content strings to edit here
├── style.css          All styling. Design tokens (colors, fonts, spacing) at the top
├── script.js          Renders data/content.js into the page + all interactivity
├── data/
│   └── content.js     ← EDIT THIS to change any real content
└── assets/
    ├── profile/        Put a real profile photo here if you want one later
    └── projects/       Put project screenshots here if you want them later
```

## Where to edit things

Everything editable lives in **`data/content.js`**:

| To change...              | Edit...                                  |
|----------------------------|-------------------------------------------|
| Name, title, bio, tagline  | `SITE_DATA.profile`                       |
| GitHub / LinkedIn / resume links | `SITE_DATA.profile.links`           |
| Email                      | `SITE_DATA.profile.email`                 |
| Education timeline         | `SITE_DATA.journey`                       |
| Projects (Featured Repositories) | `SITE_DATA.projects` (array — add/remove objects) |
| Dev Log posts              | `SITE_DATA.activity` (newest entry first) |
| Tech stack                 | `SITE_DATA.skills`                        |
| "Currently Learning" cards | `SITE_DATA.learning`                      |

The HTML and JS do not need to change for normal content updates — the page
renders everything from this one file at load time.

## Design decisions

- **Dark mode is default**, light mode is available via the toggle in the
  nav (persisted in `localStorage`). Both themes are defined as CSS custom
  properties in `:root` and `[data-theme="light"]` at the top of `style.css`
  — change a color once there and it updates everywhere.
- **Typography**: Inter for interface text, JetBrains Mono for
  technical/metadata text (tags, dates, the terminal). Loaded from Google
  Fonts in `index.html`.
- **No fabricated stats.** The "Development Activity" grid is explicitly
  labelled as illustrative and is *not* wired to real GitHub data. If you
  connect a real data source later (e.g. the GitHub contributions API),
  replace `renderActivityGraph()` in `script.js` — don't just relabel the
  fake grid.
- **Placeholders**: any link/value that hasn't been provided yet is stored
  as a string starting with `TODO` in `content.js`. `script.js` detects
  these automatically (`isPlaceholder()`) and disables/greys out the
  corresponding link instead of pointing to a dead `#`. Search `content.js`
  for `TODO` to find everything still missing (GitHub URL, LinkedIn URL,
  resume file, email, project repo/demo links).
- **Terminal easter egg**: opened via the `>_` button in the nav or the
  `` ` `` key. Commands are defined in the `commands` object inside
  `initTerminal()` in `script.js` — add a new command by adding a new key
  there.

## Adding a real project

Add a new object to the `projects` array in `data/content.js` following the
shape of the existing entries (`id`, `name`, `description`, `overview`,
`tech`, `built`, `learned`, `status`, `github`, `demo`). The card, its
"Details" modal, and the terminal's `projects` command all update
automatically — no HTML/JS changes required. Keep this list to your
strongest 3–5 projects.

## Adding a resume / profile photo

1. Drop the file into `assets/` (e.g. `assets/resume.pdf`,
   `assets/profile/photo.jpg`).
2. Update `SITE_DATA.profile.links.resume` in `data/content.js` to point to
   it.
3. For a real profile photo, swap the `<div id="avatar">` initials block in
   `index.html` for an `<img>` tag pointing at the asset — kept as initials
   for now since no photo was provided.

## Notes for the next developer (Antigravity)

- All content is data-driven from `data/content.js` — resist the urge to
  hardcode new content directly into `index.html`.
- CSS is a single file, organized top-to-bottom to match the page's visual
  order, with numbered section comments. Design tokens are all at the top.
- No CSS framework, no JS framework, no bundler — keep it that way unless
  there's a real reason to change the stack (this was a deliberate choice
  for the hackathon brief: the plain implementation is itself part of what
  is being demonstrated).
- The site is designed to degrade reasonably with JavaScript disabled: the
  static hero markup remains in the HTML, though the data-driven sections
  (projects, dev log, skills, etc.) require JS to render since they come
  from `content.js`.
