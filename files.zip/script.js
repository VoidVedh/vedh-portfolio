/**
 * script.js
 * ---------------------------------------------------------------
 * Vanilla JS only. No frameworks, no build step.
 * Renders content from data/content.js into the page, then wires
 * up interactivity: theme toggle, mobile nav, project modal, and
 * the terminal easter egg.
 * ---------------------------------------------------------------
 */

(function () {
  "use strict";

  const data = window.SITE_DATA;

  /* ---------------------------------------------------------
     Small helpers
     --------------------------------------------------------- */
  function el(tag, className, html) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  function isPlaceholder(value) {
    return !value || String(value).toUpperCase().startsWith("TODO");
  }

  /** Safely wires a link: disables it visually/functionally if it's still a TODO placeholder. */
  function wireLink(elementId, url, label) {
    const node = document.getElementById(elementId);
    if (!node) return;
    if (isPlaceholder(url)) {
      node.setAttribute("href", "#");
      node.setAttribute("aria-disabled", "true");
      node.title = (label || "Link") + " not added yet";
      node.addEventListener("click", function (e) {
        e.preventDefault();
      });
      node.style.opacity = "0.5";
      node.style.cursor = "not-allowed";
    } else {
      node.setAttribute("href", url);
    }
  }

  function formatDate(iso) {
    const d = new Date(iso + "T00:00:00");
    if (isNaN(d)) return iso;
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  }

  /* ---------------------------------------------------------
     THEME
     --------------------------------------------------------- */
  function initTheme() {
    const stored = localStorage.getItem("theme");
    const theme = stored || "dark";
    document.documentElement.setAttribute("data-theme", theme);
    updateThemeIcon(theme);

    const toggle = document.getElementById("theme-toggle");
    toggle.addEventListener("click", function () {
      const current = document.documentElement.getAttribute("data-theme");
      const next = current === "dark" ? "light" : "dark";
      document.documentElement.setAttribute("data-theme", next);
      localStorage.setItem("theme", next);
      updateThemeIcon(next);
    });
  }

  function updateThemeIcon(theme) {
    const darkIcon = document.getElementById("theme-icon-dark");
    const lightIcon = document.getElementById("theme-icon-light");
    if (theme === "dark") {
      darkIcon.style.display = "block";
      lightIcon.style.display = "none";
    } else {
      darkIcon.style.display = "none";
      lightIcon.style.display = "block";
    }
  }

  /* ---------------------------------------------------------
     MOBILE NAV
     --------------------------------------------------------- */
  function initMobileNav() {
    const toggle = document.getElementById("nav-toggle");
    const drawer = document.getElementById("mobile-drawer");

    function close() {
      drawer.hidden = true;
      toggle.setAttribute("aria-expanded", "false");
    }
    function open() {
      drawer.hidden = false;
      toggle.setAttribute("aria-expanded", "true");
    }

    toggle.addEventListener("click", function () {
      if (drawer.hidden) open(); else close();
    });

    drawer.querySelectorAll("a").forEach(function (link) {
      link.addEventListener("click", close);
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !drawer.hidden) close();
    });
  }

  /* ---------------------------------------------------------
     PROFILE / LINKS
     --------------------------------------------------------- */
  function renderProfile() {
    const p = data.profile;

    document.getElementById("hero-name").textContent = p.name;
    document.getElementById("hero-role").textContent = p.title;
    document.getElementById("hero-tagline").textContent = p.tagline;
    document.getElementById("hero-location").textContent = p.location;
    document.getElementById("about-location").textContent = p.location;
    document.getElementById("avatar").textContent = p.initials;
    document.getElementById("about-text").textContent = p.about;
    document.getElementById("footer-year").textContent = new Date().getFullYear();
    document.title = p.name + " — Computer Science Student & Developer";

    const linkTargets = [
      ["github-link", p.links.github, "GitHub"],
      ["linkedin-link", p.links.linkedin, "LinkedIn"],
      ["resume-link", p.links.resume, "Resume"],
      ["mobile-github-link", p.links.github, "GitHub"],
      ["mobile-linkedin-link", p.links.linkedin, "LinkedIn"],
      ["mobile-resume-link", p.links.resume, "Resume"],
      ["hero-github-link", p.links.github, "GitHub"],
      ["hero-linkedin-link", p.links.linkedin, "LinkedIn"],
      ["hero-resume-link", p.links.resume, "Resume"],
      ["contact-github-link", p.links.github, "GitHub"],
      ["contact-linkedin-link", p.links.linkedin, "LinkedIn"],
      ["footer-github-link", p.links.github, "GitHub"],
      ["footer-linkedin-link", p.links.linkedin, "LinkedIn"]
    ];
    linkTargets.forEach(function (t) { wireLink(t[0], t[1], t[2]); });

    const emailNode = document.getElementById("contact-email-link");
    if (isPlaceholder(p.email)) {
      emailNode.setAttribute("href", "#");
      emailNode.title = "Email not added yet";
      emailNode.style.opacity = "0.5";
      emailNode.addEventListener("click", function (e) { e.preventDefault(); });
    } else {
      emailNode.setAttribute("href", "mailto:" + p.email);
    }
  }

  /* ---------------------------------------------------------
     PROJECTS / FEATURED REPOSITORIES
     --------------------------------------------------------- */
  const repoIconSVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"/></svg>';

  function renderProjects() {
    const grid = document.getElementById("repo-grid");
    grid.innerHTML = "";

    data.projects.forEach(function (project) {
      const card = el("article", "repo-card");

      const top = el("div", "repo-card-top");
      const icon = el("div", "repo-icon", repoIconSVG);
      const status = el("span", "repo-status", project.status);
      top.append(icon, status);

      const name = el("h3", "repo-name", project.name);
      const desc = el("p", "repo-desc", project.description);

      const tags = el("div", "repo-tags");
      project.tech.forEach(function (t) {
        tags.appendChild(el("span", "tag", t));
      });

      const footer = el("div", "repo-footer");

      const detailsBtn = el("button", "btn btn-sm", "Details");
      detailsBtn.type = "button";
      detailsBtn.addEventListener("click", function () { openProjectModal(project); });
      footer.appendChild(detailsBtn);

      if (!isPlaceholder(project.demo)) {
        const demoLink = el("a", "btn btn-sm", "Live Demo");
        demoLink.href = project.demo;
        demoLink.target = "_blank";
        demoLink.rel = "noopener";
        footer.appendChild(demoLink);
      }

      const ghLink = el("a", "btn btn-sm", "GitHub");
      if (isPlaceholder(project.github)) {
        ghLink.href = "#";
        ghLink.style.opacity = "0.5";
        ghLink.title = "GitHub URL not added yet";
        ghLink.addEventListener("click", function (e) { e.preventDefault(); });
      } else {
        ghLink.href = project.github;
        ghLink.target = "_blank";
        ghLink.rel = "noopener";
      }
      footer.appendChild(ghLink);

      card.append(top, name, desc, tags, footer);
      grid.appendChild(card);
    });
  }

  /* ---------------------------------------------------------
     PROJECT MODAL
     --------------------------------------------------------- */
  function openProjectModal(project) {
    document.getElementById("modal-title").textContent = project.name;
    document.getElementById("modal-status").textContent = project.status;
    document.getElementById("modal-overview").textContent = project.overview;

    const techWrap = document.getElementById("modal-tech");
    techWrap.innerHTML = "";
    project.tech.forEach(function (t) { techWrap.appendChild(el("span", "tag", t)); });

    const builtList = document.getElementById("modal-built");
    builtList.innerHTML = "";
    project.built.forEach(function (item) { builtList.appendChild(el("li", null, item)); });

    const learnedList = document.getElementById("modal-learned");
    learnedList.innerHTML = "";
    project.learned.forEach(function (item) { learnedList.appendChild(el("li", null, item)); });

    const linksWrap = document.getElementById("modal-links");
    linksWrap.innerHTML = "";
    if (!isPlaceholder(project.github)) {
      const gh = el("a", "btn btn-sm", "View on GitHub");
      gh.href = project.github; gh.target = "_blank"; gh.rel = "noopener";
      linksWrap.appendChild(gh);
    }
    if (!isPlaceholder(project.demo)) {
      const demo = el("a", "btn btn-sm btn-primary", "Live Demo");
      demo.href = project.demo; demo.target = "_blank"; demo.rel = "noopener";
      linksWrap.appendChild(demo);
    }

    const overlay = document.getElementById("project-modal");
    overlay.hidden = false;
    document.getElementById("modal-close-btn").focus();
    document.body.style.overflow = "hidden";
  }

  function closeProjectModal() {
    document.getElementById("project-modal").hidden = true;
    document.body.style.overflow = "";
  }

  function initModal() {
    document.getElementById("modal-close-btn").addEventListener("click", closeProjectModal);
    document.getElementById("project-modal").addEventListener("click", function (e) {
      if (e.target === e.currentTarget) closeProjectModal();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !document.getElementById("project-modal").hidden) closeProjectModal();
    });
  }

  /* ---------------------------------------------------------
     DEV LOG
     --------------------------------------------------------- */
  function renderActivity() {
    const list = document.getElementById("devlog-list");
    list.innerHTML = "";

    data.activity.forEach(function (post) {
      const item = el("article", "devlog-item");

      const avatar = el("div", "devlog-avatar", data.profile.initials);

      const body = el("div");
      const head = el("div", "devlog-head");
      head.appendChild(el("span", "devlog-name", data.profile.name));
      head.appendChild(el("span", "devlog-handle", data.profile.handle));
      head.appendChild(el("span", "devlog-date", formatDate(post.date)));

      const content = el("p", "devlog-content", post.content);

      body.append(head, content);

      if (post.tags && post.tags.length) {
        const tagsWrap = el("div", "devlog-tags");
        post.tags.forEach(function (t) { tagsWrap.appendChild(el("span", null, "#" + t)); });
        body.appendChild(tagsWrap);
      }

      item.append(avatar, body);
      list.appendChild(item);
    });
  }

  /* ---------------------------------------------------------
     SKILLS
     --------------------------------------------------------- */
  function renderSkills() {
    const grid = document.getElementById("skills-grid");
    grid.innerHTML = "";

    data.skills.forEach(function (group) {
      const card = el("div", "skill-card");
      card.appendChild(el("h3", null, group.category));
      const tagsWrap = el("div", "skill-tags");
      group.items.forEach(function (item) { tagsWrap.appendChild(el("span", "tag", item)); });
      card.appendChild(tagsWrap);
      grid.appendChild(card);
    });
  }

  /* ---------------------------------------------------------
     CURRENTLY LEARNING
     --------------------------------------------------------- */
  function renderLearning() {
    const grid = document.getElementById("learning-grid");
    grid.innerHTML = "";

    data.learning.forEach(function (item) {
      const card = el("div", "learning-card");
      const top = el("div", "learning-card-top");
      top.appendChild(el("span", "pulse-dot"));
      top.appendChild(el("h3", null, item.area));
      card.appendChild(top);
      card.appendChild(el("p", null, item.detail));
      grid.appendChild(card);
    });
  }

  /* ---------------------------------------------------------
     JOURNEY
     --------------------------------------------------------- */
  function renderJourney() {
    const list = document.getElementById("journey-list");
    list.innerHTML = "";

    data.journey.forEach(function (step) {
      const item = el("div", "journey-item");
      item.appendChild(el("div", "journey-year", step.year));
      item.appendChild(el("div", "journey-title", step.title));
      item.appendChild(el("div", "journey-place", step.place));
      if (step.detail) item.appendChild(el("div", "journey-detail", step.detail));
      list.appendChild(item);
    });
  }

  /* ---------------------------------------------------------
     DEVELOPMENT ACTIVITY GRID (illustrative only — not real GitHub data)
     --------------------------------------------------------- */
  function renderActivityGraph() {
    const graph = document.getElementById("activity-graph");
    graph.innerHTML = "";

    const weeks = 20;
    const days = 7;
    // Deterministic pseudo-random pattern so it looks the same on every load
    // rather than genuinely random noise, while making clear it is not live data.
    let seed = 42;
    function next() {
      seed = (seed * 9301 + 49297) % 233280;
      return seed / 233280;
    }

    for (let w = 0; w < weeks; w++) {
      for (let d = 0; d < days; d++) {
        const intensity = next();
        const cell = el("div", "activity-cell");
        if (intensity > 0.85) {
          cell.style.background = "var(--accent)";
        } else if (intensity > 0.65) {
          cell.style.background = "var(--accent)";
          cell.style.opacity = "0.6";
        } else if (intensity > 0.45) {
          cell.style.background = "var(--accent)";
          cell.style.opacity = "0.3";
        }
        graph.appendChild(cell);
      }
    }

    document.getElementById("activity-note").textContent = data.activityNote;
  }

  /* ---------------------------------------------------------
     TERMINAL EASTER EGG
     --------------------------------------------------------- */
  function initTerminal() {
    const overlay = document.getElementById("terminal-overlay");
    const body = document.getElementById("terminal-body");
    const input = document.getElementById("terminal-input");
    const openBtn = document.getElementById("terminal-open-btn");
    const closeBtn = document.getElementById("terminal-close-btn");

    let opened = false;

    function print(text, cls) {
      const line = el("div", "terminal-line" + (cls ? " " + cls : ""), text);
      body.appendChild(line);
      body.scrollTop = body.scrollHeight;
    }

    function printBlock(lines, cls) {
      lines.forEach(function (l) { print(l, cls); });
    }

    function welcome() {
      body.innerHTML = "";
      printBlock([
        "vedh@portfolio:~$ welcome",
        "Vedh Naik — developer terminal.",
        "Type \"help\" to see available commands."
      ], "dim");
      print("");
    }

    const commands = {
      help: function () {
        printBlock([
          "Available commands:",
          "",
          "  about      show a short bio",
          "  projects   list featured projects",
          "  skills     list the tech stack",
          "  activity   show recent dev log entries",
          "  journey    show the education timeline",
          "  contact    show contact info",
          "  whoami     who is using this terminal",
          "  clear      clear the terminal",
          "  exit       close the terminal"
        ]);
      },
      about: function () {
        printBlock([
          data.profile.fullName,
          data.profile.title + ".",
          data.profile.tagline
        ]);
      },
      whoami: function () {
        print("vedh");
      },
      projects: function () {
        print("");
        data.projects.forEach(function (p) {
          print(p.name);
          print("  " + p.description, "dim");
          print("  tech: " + p.tech.join(", "), "dim");
          print("");
        });
      },
      skills: function () {
        print("");
        data.skills.forEach(function (group) {
          print(group.category + ":");
          print("  " + group.items.join(", "), "dim");
        });
      },
      activity: function () {
        print("");
        data.activity.slice(0, 5).forEach(function (post) {
          print(formatDate(post.date) + " — " + post.content);
        });
      },
      journey: function () {
        print("");
        data.journey.forEach(function (step) {
          print(step.year + "  " + step.title + " — " + step.place);
        });
      },
      contact: function () {
        printBlock([
          "email:    " + (isPlaceholder(data.profile.email) ? "not added yet" : data.profile.email),
          "github:   " + (isPlaceholder(data.profile.links.github) ? "not added yet" : data.profile.links.github),
          "linkedin: " + (isPlaceholder(data.profile.links.linkedin) ? "not added yet" : data.profile.links.linkedin)
        ]);
      },
      clear: function () {
        body.innerHTML = "";
      },
      exit: function () {
        close();
      }
    };

    function runCommand(raw) {
      const cmd = raw.trim().toLowerCase();
      print("vedh@portfolio:~$ " + raw, "cmd");
      if (!cmd) return;
      if (commands[cmd]) {
        commands[cmd]();
      } else {
        print('Command not found: "' + cmd + '". Type "help" for a list of commands.', "err");
      }
      print("");
    }

    function open() {
      overlay.hidden = false;
      document.body.style.overflow = "hidden";
      if (!opened) {
        welcome();
        opened = true;
      }
      input.value = "";
      setTimeout(function () { input.focus(); }, 10);
    }

    function close() {
      overlay.hidden = true;
      document.body.style.overflow = "";
      openBtn.focus();
    }

    openBtn.addEventListener("click", open);
    closeBtn.addEventListener("click", close);
    overlay.addEventListener("click", function (e) {
      if (e.target === e.currentTarget) close();
    });

    input.addEventListener("keydown", function (e) {
      if (e.key === "Enter") {
        const val = input.value;
        input.value = "";
        runCommand(val);
      }
    });

    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape" && !overlay.hidden) close();
      // Keyboard shortcut: "`" opens the terminal from anywhere
      if (e.key === "`" && overlay.hidden && document.activeElement.tagName !== "INPUT") {
        e.preventDefault();
        open();
      }
    });
  }

  /* ---------------------------------------------------------
     INIT
     --------------------------------------------------------- */
  document.addEventListener("DOMContentLoaded", function () {
    initTheme();
    initMobileNav();
    renderProfile();
    renderProjects();
    initModal();
    renderActivity();
    renderSkills();
    renderLearning();
    renderJourney();
    renderActivityGraph();
    initTerminal();
  });
})();
