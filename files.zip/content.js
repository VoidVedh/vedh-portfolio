/**
 * content.js
 * ---------------------------------------------------------------
 * ALL editable content for the site lives in this file.
 * Change your name, links, projects, activity posts, skills,
 * education and journey here — the HTML/CSS never need to change
 * for a normal content update.
 *
 * Search for "TODO" to find every placeholder that still needs a
 * real value (URLs, resume file, etc).
 * ---------------------------------------------------------------
 */

const SITE_DATA = {

  // ---------------------------------------------------------
  // PROFILE / IDENTITY
  // ---------------------------------------------------------
  profile: {
    name: "Vedh Naik",
    fullName: "Vedh Jayesh Naik",
    initials: "VN",
    title: "Computer Science Student · Developer",
    tagline: "Building software, exploring cybersecurity, and learning machine learning.",
    location: "Navi Mumbai / Mumbai, India",
    handle: "@vedhdev",
    email: "TODO_ADD_EMAIL@example.com", // TODO: replace with real email
    about: "I'm a Computer Science student interested in building software and understanding how systems actually work underneath. My focus right now spans web development, cybersecurity fundamentals, cloud infrastructure and machine learning. I learn mostly by building — trying things, breaking them, and figuring out why.",
    links: {
      github: "TODO_ADD_GITHUB_URL",       // TODO: Add actual GitHub profile URL
      linkedin: "TODO_ADD_LINKEDIN_URL",   // TODO: Add actual LinkedIn profile URL
      resume: "TODO_ADD_RESUME_FILE.pdf"   // TODO: Add resume file to assets/ and link it here
    }
  },

  // ---------------------------------------------------------
  // EDUCATION / JOURNEY
  // Keep in chronological order — rendered as a timeline.
  // ---------------------------------------------------------
  journey: [
    {
      year: "2022",
      title: "Class X — ICSE",
      place: "Vibgyor High School, Airoli",
      detail: "76.17%"
    },
    {
      year: "2022 – 2025",
      title: "Diploma in Computer Engineering",
      place: "VPM Polytechnic, Thane",
      detail: "71.94%"
    },
    {
      year: "2025 – Present",
      title: "B.Tech, Computer Science & Engineering",
      place: "ITM, Kharghar",
      detail: "In progress"
    },
    {
      year: "2026",
      title: "Expanding into new territory",
      place: "Self-directed learning",
      detail: "Going deeper on development, cybersecurity, cloud and machine learning."
    }
  ],

  // ---------------------------------------------------------
  // FEATURED PROJECTS
  // Add / remove objects here — cards render automatically.
  // Keep this list to your strongest 3–5 projects.
  // Do not add a project unless it's real — no fabricated
  // features, stats, links or testimonials.
  // ---------------------------------------------------------
  projects: [
    {
      id: "sportxtreme",
      name: "SportXtreme Events",
      description: "A responsive web platform for discovering and showcasing active sports events.",
      overview: "SportXtreme Events is a responsive front-end web platform built to showcase active sports events in a clean, browsable format. It was built and deployed as a hands-on exercise in structuring a real front-end project from the ground up — componentised layout, responsive breakpoints and a deployed build.",
      tech: ["React", "HTML5", "CSS3", "Git", "GitHub"],
      built: [
        "A responsive React front-end for browsing sports events",
        "Reusable component structure for event listings",
        "A mobile-first responsive layout"
      ],
      learned: [
        "Structuring a React project for a real, deployed build",
        "Writing responsive CSS across multiple breakpoints",
        "Using Git/GitHub for version control on a full project"
      ],
      status: "Deployed",
      featured: true,
      github: "TODO_ADD_GITHUB_URL_FOR_SPORTXTREME",   // TODO: Add repository URL
      demo: "TODO_ADD_LIVE_DEMO_URL"                    // TODO: Add live deployment URL
    },
    {
      id: "networks-lab",
      name: "Academic Networks & Environment Lab",
      description: "An academic networking & cybersecurity lab exploring device discovery and packet analysis.",
      overview: "An academic project focused on networking fundamentals and introductory cybersecurity practice using a WSL-based Linux environment. The work centered on understanding how devices communicate on a network, not on any professional security engagement.",
      tech: ["WSL", "Linux", "Nmap", "Wireshark", "Networking Fundamentals"],
      built: [
        "A WSL-based Linux environment for network experimentation",
        "Device and open-port discovery workflows using Nmap",
        "Packet capture and inspection setups using Wireshark"
      ],
      learned: [
        "How HTTP/TCP packets look and behave on the wire",
        "Basic device and port discovery on a local network",
        "Core networking fundamentals that underlie most security tooling"
      ],
      status: "Academic project",
      featured: true,
      github: "TODO_ADD_GITHUB_URL_FOR_NETWORKS_LAB", // TODO: Add repository URL if published
      demo: null
    }
    // TODO: Add 1–3 more real projects here as they're ready.
    // Copy the object shape above — set demo: null if there isn't a live link.
  ],

  // ---------------------------------------------------------
  // DEV LOG (personal developer updates — not real social posts)
  // Newest first.
  // ---------------------------------------------------------
  activity: [
    {
      date: "2026-08-14",
      content: "Currently learning Decision Trees with Python and Scikit-learn — trying to actually understand the algorithm rather than just calling the library.",
      tags: ["machine-learning", "python"]
    },
    {
      date: "2026-08-02",
      content: "Building this portfolio from scratch. Trying to make it feel like an actual developer profile instead of another student resume in a browser tab.",
      tags: ["portfolio", "web-dev"]
    },
    {
      date: "2026-07-20",
      content: "Spent the week going deeper into Linux, networking and cybersecurity fundamentals — Nmap and Wireshark are becoming a lot less mysterious.",
      tags: ["cybersecurity", "linux", "networking"]
    },
    {
      date: "2026-07-05",
      content: "Started exploring Docker and Docker Compose to understand how multi-service apps are actually run, not just deployed by a tutorial script.",
      tags: ["devops", "docker"]
    },
    {
      date: "2026-06-22",
      content: "Working through AWS fundamentals — EC2, IAM and VPC — by setting up and tearing down small environments rather than just reading docs.",
      tags: ["cloud", "aws"]
    }
    // TODO: Keep adding new entries at the top as you build/learn.
  ],

  // ---------------------------------------------------------
  // SKILLS / TECH STACK
  // No proficiency percentages — just an honest, categorised list.
  // ---------------------------------------------------------
  skills: [
    {
      category: "Programming",
      items: ["Python", "C++", "Java", "SQL"]
    },
    {
      category: "Web",
      items: ["HTML", "CSS", "JavaScript", "React"]
    },
    {
      category: "Backend",
      items: ["Node.js", "Express", "MongoDB", "MySQL", "Firebase", "Supabase"]
    },
    {
      category: "Cloud / DevOps",
      items: ["AWS EC2", "AWS IAM", "AWS VPC", "AWS S3", "Docker", "Docker Compose", "Terraform", "Jenkins", "Nginx", "Linux"]
    },
    {
      category: "Cybersecurity",
      items: ["Kali Linux", "Nmap", "Wireshark", "WSL", "Networking Fundamentals"]
    },
    {
      category: "Machine Learning",
      items: ["Python (ML stack)", "Scikit-learn"]
    }
  ],

  // ---------------------------------------------------------
  // CURRENTLY LEARNING
  // ---------------------------------------------------------
  learning: [
    {
      area: "Machine Learning",
      detail: "Working through core algorithms with Python and Scikit-learn."
    },
    {
      area: "Cybersecurity",
      detail: "Building on networking fundamentals — Nmap, Wireshark, Kali Linux."
    },
    {
      area: "Cloud / DevOps",
      detail: "Hands-on with AWS, Docker, Terraform and Jenkins."
    },
    {
      area: "Backend Development",
      detail: "Deepening Node.js, Express and database design."
    }
  ],

  // ---------------------------------------------------------
  // DEVELOPMENT ACTIVITY (placeholder learning-activity grid)
  // NOT connected to real GitHub data. Replace `generateActivityData()`
  // in script.js with a real data source if/when one exists —
  // never hardcode a specific contribution count here.
  // ---------------------------------------------------------
  activityNote: "A lightweight view of learning/building activity over the last few months. Not connected to live GitHub data yet."
};
